<?php
	   
	class Fondy
	{
		const ORDER_APPROVED = 'approved';
		const ORDER_DECLINED = 'declined';
		const ORDER_SEPARATOR = '#';
		const SIGNATURE_SEPARATOR = '|';
		const URL = "https://payment.albpay.io/api/checkout/redirect/";
		
		public static function getSignature($data, $password, $encoded = true)
		{
			$data = array_filter($data, function($var) {
				return $var !== '' && $var !== null;
			});
			ksort($data);

			$str = $password;
			foreach ($data as $k => $v) {
				$str .= self::SIGNATURE_SEPARATOR . $v;
			}
		
			if ($encoded) {
				return sha1($str);
				} else {
				return $str;
			}
		}
		
		public static function isPaymentValid($fondySettings, $response)
		{
			
			if ($fondySettings['merchant_id'] != $response['merchant_id']) {
				return false;
			}
			if ($response['order_status'] != 'approved') {
				return false;
			}
			$responseSignature = $response['signature'];
			
			if (isset($response['response_signature_string'])){
				unset($response['response_signature_string']);
			}
			if (isset($response['signature'])){
				unset($response['signature']);
			}
			$response['merchant_data'] = stripslashes($response['merchant_data']);
			if (Fondy::getSignature($response, $fondySettings['secret_key']) != $responseSignature) {
				
				return false;
			}
			
			return true;
		}
		
		
	}