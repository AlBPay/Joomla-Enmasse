<?php
/* ------------------------------------------------------------------------
  # En Masse - Social Buying Extension 2010
  # ------------------------------------------------------------------------
  # By Matamko.com
  # Copyright (C) 2010 Matamko.com. All Rights Reserved.
  # @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
  # Websites: http://www.matamko.com
  # Technical Support:  Visit our forum at www.matamko.com
  ------------------------------------------------------------------------- */
// No direct access 
defined( '_JEXEC' ) or die( 'Restricted access' ); 


//------------------------------------------------------------------------
// Class for providing the encapsulation of the Payment Gateway

class PayGtyFondy {

	public static function returnStatus()
	{
	  $status ->coupon = 'Free';
	  $status ->order  = 'Unpaid';
	  return $status;
	}
	    
	public static function checkConfig($payGty)
	{
		
		$attribute_config = json_decode($payGty->attribute_config);
	
		if ( !isset($attribute_config->MerchanID) || trim($attribute_config->MerchanID) == "" and  !isset($attribute_config->SecretKey) || trim($attribute_config->SecretKey))
		{
			return false;
		}	
		return true;
	}    
	
	public static function validateTxn($payClass)
	{
		include ('fondy.php');
        $payGty = JModelLegacy::getInstance('payGty','enmasseModel')->getByClass("fondy");
		$attribute_config = json_decode($payGty->attribute_config);
        
        $data = array();
        
        foreach ($_POST as $field=>$value)
        {
            $data["$field"] = $value;
        }
		
        $vendorNumber   = ($data["vendor_number"] != '') ? $data["vendor_number"] : $data["merchant_id"];
        $orderNumber    = explode('#',$data["order_id"])[0];
        $orderTotal     = $data["actual_amount"]/100;
		$fondySettings = [
		'merchant_id' => $attribute_config->MerchanID,
		'secret_key' => $attribute_config->SecretKey
		];
		$valid = Fondy::isPaymentValid($fondySettings,$data);
		
        // verify if the key is accurate
        if($valid == true)
        {
            return true;
        }
        else
        {
            return false;
        }
	}
	
	public static function generatePaymentDetail()
	{
		$paymentDta = array();
		
		$paymentDta["order_number"]             = explode('#',$_REQUEST['order_id'])[0];
        $paymentDta["invoice_id"]               = $_REQUEST['payment_id'];
        $paymentDta["pay_method"]               = $_REQUEST['payClass'];
        $paymentDta["card_holder_name"]         = $_REQUEST['card_holder_name'];
        $paymentDta["total"]                    = $_REQUEST["actual_amount"]/100; 
		
		return $paymentDta;		
	}	
}
 
?>
